NOOR US SAMA WEBSITE
====================

Files:
- index.html   Main page/content
- styles.css   Colors, typography, layouts, responsive styling
- script.js    Menu, scroll animations, WhatsApp service links

Verified business details used:
- Noor Us Sama - نوراسماء
- Jewelry store
- Shop 154, First Floor, Centaurus Mall, F-8/4, Islamabad 46000, Pakistan
- Phone: +92 304 9070090
- Alternate phone: +92 304 9070065
- Email: Info@noorussama.com
- Opening hours: Monday-Sunday, 10:00 AM-9:00 PM

Editing:
- Change colors at the top of styles.css under :root
- Change content directly in index.html
- Change the WhatsApp number in index.html and script.js
- Gallery images are illustrative Unsplash imagery and can be replaced by changing image URLs in index.html

No build tools or frameworks are required. Open index.html directly in a browser or upload all three files to any static web host.
